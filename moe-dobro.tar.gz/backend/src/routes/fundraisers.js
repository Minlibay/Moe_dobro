const express = require('express');
const router = express.Router();
const fundraiserController = require('../controllers/fundraiserController');
const authMiddleware = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', fundraiserController.getAllFundraisers);
router.get('/my', authMiddleware, fundraiserController.getMyFundraisers);
router.get('/:id', fundraiserController.getFundraiserById);
router.post('/', authMiddleware, upload.single('image'), fundraiserController.createFundraiser);
router.patch('/:id/close', authMiddleware, fundraiserController.closeFundraiser);
router.post('/:id/completion-proof', authMiddleware, upload.single('proof'), fundraiserController.submitCompletionProof);

module.exports = router;
